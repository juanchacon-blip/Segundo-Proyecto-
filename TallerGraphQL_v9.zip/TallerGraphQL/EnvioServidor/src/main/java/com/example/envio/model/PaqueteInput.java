package com.example.envio.model;

public record PaqueteInput(String codigo, String envioCodigo, String descripcion, double pesoKg,
                           int unidades, String fechaRegistro, boolean fragil) {
}
