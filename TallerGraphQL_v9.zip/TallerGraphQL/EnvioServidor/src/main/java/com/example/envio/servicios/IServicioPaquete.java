package com.example.envio.servicios;

import com.example.envio.model.Paquete;
import com.example.envio.model.PaqueteInput;

import java.util.List;
import java.util.Optional;

/** Contrato del servicio de paquetes (detalle). Los controladores dependen de esta interfaz (SOLID: DIP). */
public interface IServicioPaquete {

    List<Paquete> listarPaquetes();

    List<Paquete> filtrarPaquetes(String envioCodigo, String descripcion);

    Optional<Paquete> buscarPorCodigo(String codigo);

    Optional<Paquete> buscarPorCriterios(String codigo, String envioCodigo, String descripcion);

    /** Vacio si el codigo ya existe o si el envio (maestro) no existe. */
    Optional<Paquete> addPaquete(PaqueteInput input);

    /** Actualiza los datos del paquete; el envio al que pertenece no cambia. */
    Optional<Paquete> updatePaquete(PaqueteInput input);

    Optional<Paquete> deletePaquete(String codigo);
}
