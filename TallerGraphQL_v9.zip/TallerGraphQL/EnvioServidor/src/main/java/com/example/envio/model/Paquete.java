package com.example.envio.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * DETALLE de la relacion maestro-detalle: un EnvioNacional (1..1) contiene 0..* paquetes.
 * Atributos: String (codigo, envioCodigo, descripcion), double (pesoKg), int (unidades),
 * LocalDateTime (fechaRegistro) y boolean (fragil).
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Paquete {
    private String codigo;
    private String envioCodigo;
    private String descripcion;
    private double pesoKg;
    private int unidades;
    private LocalDateTime fechaRegistro;
    private boolean fragil;
}
