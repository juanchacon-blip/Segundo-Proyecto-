package com.example.envio.model;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class EnvioNacional extends Envio {
    private String departamentoDestino;
    private int codigoPostalNacional;

    // MAESTRO de la relacion maestro-detalle: un envio (1..1) tiene 0..* paquetes.
    private final List<Paquete> paquetes = new CopyOnWriteArrayList<>();

    public EnvioNacional(String codigo, String origen, String destino, double precio,
                         LocalDateTime fechaSalida, String departamentoDestino, int codigoPostalNacional) {
        super(codigo, origen, destino, precio, fechaSalida);
        this.departamentoDestino = departamentoDestino;
        this.codigoPostalNacional = codigoPostalNacional;
    }
}
