package com.example.envio.controller;

import com.example.envio.model.EnvioNacional;
import com.example.envio.model.EnvioNacionalInput;
import com.example.envio.servicios.IServicioEnvioNacional;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.Optional;

@Controller
public class EnvioNacionalController {

    private final IServicioEnvioNacional servicio;

    public EnvioNacionalController(IServicioEnvioNacional servicio) {
        this.servicio = servicio;
    }

    @QueryMapping
    public List<EnvioNacional> enviosNacionales() {
        return servicio.listarEnvios();
    }

    @QueryMapping
    public List<EnvioNacional> enviosNacionalesFiltrados(@Argument String origen, @Argument String departamentoDestino) {
        return servicio.filtrarEnvios(origen, departamentoDestino);
    }

    @QueryMapping
    public Optional<EnvioNacional> envioNacionalPorCodigo(@Argument String codigo) {
        return servicio.buscarPorCodigo(codigo);
    }

    @QueryMapping
    public Optional<EnvioNacional> envioNacionalPorCriterios(@Argument String codigo, @Argument String origen,
                                                             @Argument String destino) {
        return servicio.buscarPorCriterios(codigo, origen, destino);
    }

    @MutationMapping
    public Optional<EnvioNacional> addEnvioNacional(@Argument("input") EnvioNacionalInput input) {
        return servicio.addEnvio(input);
    }

    @MutationMapping
    public Optional<EnvioNacional> updateEnvioNacional(@Argument("input") EnvioNacionalInput input) {
        return servicio.updateEnvio(input);
    }

    @MutationMapping
    public Optional<EnvioNacional> deleteEnvioNacional(@Argument String codigo) {
        return servicio.deleteEnvio(codigo);
    }

}
