package com.example.envio.servicios;

import com.example.envio.model.EnvioNacional;
import com.example.envio.model.Paquete;
import com.example.envio.model.PaqueteInput;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/**
 * Gestiona los paquetes (detalle). Cada paquete vive en la coleccion de su EnvioNacional (maestro),
 * que se obtiene a traves de IServicioEnvioNacional (no de la clase concreta).
 * Singleton con "holder idiom", igual que ServicioEnvioNacional.
 */
public class ServicioPaquete implements IServicioPaquete {

    private static class Holder {
        private static final ServicioPaquete INSTANCIA = new ServicioPaquete(ServicioEnvioNacional.getInstance());
    }

    public static ServicioPaquete getInstance() {
        return Holder.INSTANCIA;
    }

    private final IServicioEnvioNacional servicioEnvios;

    private ServicioPaquete(IServicioEnvioNacional servicioEnvios) {
        this.servicioEnvios = servicioEnvios;
    }

    private static boolean vacio(String s) {
        return s == null || s.isBlank();
    }

    @Override
    public List<Paquete> listarPaquetes() {
        return servicioEnvios.listarEnvios().stream()
                .flatMap(e -> e.getPaquetes().stream())
                .toList();
    }

    @Override
    public List<Paquete> filtrarPaquetes(String envioCodigo, String descripcion) {
        return listarPaquetes().stream()
                .filter(p -> vacio(envioCodigo) || p.getEnvioCodigo().equalsIgnoreCase(envioCodigo.trim()))
                .filter(p -> vacio(descripcion)
                        || p.getDescripcion().toLowerCase().contains(descripcion.trim().toLowerCase()))
                .toList();
    }

    @Override
    public Optional<Paquete> buscarPorCodigo(String codigo) {
        if (vacio(codigo)) {
            return Optional.empty();
        }
        return listarPaquetes().stream()
                .filter(p -> p.getCodigo().equalsIgnoreCase(codigo.trim()))
                .findFirst();
    }

    @Override
    public Optional<Paquete> buscarPorCriterios(String codigo, String envioCodigo, String descripcion) {
        if (vacio(codigo) && vacio(envioCodigo) && vacio(descripcion)) {
            return Optional.empty();
        }
        return listarPaquetes().stream()
                .filter(p -> vacio(codigo) || p.getCodigo().equalsIgnoreCase(codigo.trim()))
                .filter(p -> vacio(envioCodigo) || p.getEnvioCodigo().equalsIgnoreCase(envioCodigo.trim()))
                .filter(p -> vacio(descripcion)
                        || p.getDescripcion().toLowerCase().contains(descripcion.trim().toLowerCase()))
                .findFirst();
    }

    @Override
    public synchronized Optional<Paquete> addPaquete(PaqueteInput input) {
        Optional<EnvioNacional> envio = servicioEnvios.buscarPorCodigo(input.envioCodigo());
        if (envio.isEmpty() || buscarPorCodigo(input.codigo()).isPresent()) {
            return Optional.empty();
        }
        Paquete paquete = new Paquete(input.codigo().trim(), envio.get().getCodigo(), input.descripcion(),
                input.pesoKg(), input.unidades(), LocalDateTime.parse(input.fechaRegistro()), input.fragil());
        envio.get().getPaquetes().add(paquete);
        return Optional.of(paquete);
    }

    @Override
    public synchronized Optional<Paquete> updatePaquete(PaqueteInput input) {
        Optional<Paquete> paquete = buscarPorCodigo(input.codigo());
        paquete.ifPresent(p -> {
            p.setDescripcion(input.descripcion());
            p.setPesoKg(input.pesoKg());
            p.setUnidades(input.unidades());
            p.setFechaRegistro(LocalDateTime.parse(input.fechaRegistro()));
            p.setFragil(input.fragil());
        });
        return paquete;
    }

    @Override
    public synchronized Optional<Paquete> deletePaquete(String codigo) {
        Optional<Paquete> paquete = buscarPorCodigo(codigo);
        paquete.ifPresent(p -> servicioEnvios.buscarPorCodigo(p.getEnvioCodigo())
                .ifPresent(e -> e.getPaquetes().remove(p)));
        return paquete;
    }
}
