package com.example.envio.servicios;

import com.example.envio.model.EnvioNacional;
import com.example.envio.model.EnvioNacionalInput;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;

public class ServicioEnvioNacional implements IServicioEnvioNacional {
    // Patron Singleton: una unica instancia compartida por todos los clientes.
    // Se usa el "holder idiom": la instancia se crea de forma perezosa y es segura entre hilos.
    private static class Holder {
        private static final ServicioEnvioNacional INSTANCIA = new ServicioEnvioNacional();
    }

    public static ServicioEnvioNacional getInstance() {
        return Holder.INSTANCIA;
    }

    // Coleccion en memoria (requisito del proyecto). Segura para varias peticiones simultaneas.
    private final List<EnvioNacional> envios = new CopyOnWriteArrayList<>();

    private ServicioEnvioNacional() {
    }

    @Override
    public List<EnvioNacional> listarEnvios() {
        return List.copyOf(envios);
    }

    @Override
    public List<EnvioNacional> filtrarEnvios(String origen, String departamentoDestino) {
        return envios.stream()
                .filter(e -> origen == null || origen.isBlank() || e.getOrigen().equalsIgnoreCase(origen))
                .filter(e -> departamentoDestino == null || departamentoDestino.isBlank()
                        || e.getDepartamentoDestino().equalsIgnoreCase(departamentoDestino))
                .toList();
    }

    @Override
    public Optional<EnvioNacional> buscarPorCodigo(String codigo) {
        return envios.stream()
                .filter(e -> e.getCodigo().equalsIgnoreCase(codigo))
                .findFirst();
    }

    @Override
    public Optional<EnvioNacional> buscarPorCriterios(String codigo, String origen, String destino) {
        boolean sinCodigo = codigo == null || codigo.isBlank();
        boolean sinOrigen = origen == null || origen.isBlank();
        boolean sinDestino = destino == null || destino.isBlank();

        if (sinCodigo && sinOrigen && sinDestino) {
            return Optional.empty();
        }

        return envios.stream()
                .filter(e -> sinCodigo || e.getCodigo().equalsIgnoreCase(codigo.trim()))
                .filter(e -> sinOrigen || e.getOrigen().equalsIgnoreCase(origen.trim()))
                .filter(e -> sinDestino || e.getDestino().equalsIgnoreCase(destino.trim()))
                .findFirst();
    }

    @Override
    public synchronized Optional<EnvioNacional> addEnvio(EnvioNacionalInput input) {
        if (buscarPorCodigo(input.codigo()).isPresent()) {
            return Optional.empty();
        }
        EnvioNacional envio = new EnvioNacional(input.codigo(), input.origen(), input.destino(), input.precio(),
                LocalDateTime.parse(input.fechaSalida()), input.departamentoDestino(), input.codigoPostalNacional());
        envios.add(envio);

        return Optional.of(envio);
    }

    @Override
    public synchronized Optional<EnvioNacional> updateEnvio(EnvioNacionalInput input) {
        Optional<EnvioNacional> envio = buscarPorCodigo(input.codigo());
        envio.ifPresent(e -> {
            e.setOrigen(input.origen());
            e.setDestino(input.destino());
            e.setPrecio(input.precio());
            e.setFechaSalida(LocalDateTime.parse(input.fechaSalida()));
            e.setDepartamentoDestino(input.departamentoDestino());
            e.setCodigoPostalNacional(input.codigoPostalNacional());
        });

        return envio;
    }

    @Override
    public synchronized Optional<EnvioNacional> deleteEnvio(String codigo) {
        Optional<EnvioNacional> envio = buscarPorCodigo(codigo);
        envio.ifPresent(envios::remove);

        return envio;
    }

}
