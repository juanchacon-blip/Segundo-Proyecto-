package com.example.envio.controller;

import com.example.envio.model.Paquete;
import com.example.envio.model.PaqueteInput;
import com.example.envio.servicios.IServicioPaquete;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;
import java.util.Optional;

@Controller
public class PaqueteController {

    private final IServicioPaquete servicio;

    public PaqueteController(IServicioPaquete servicio) {
        this.servicio = servicio;
    }

    @QueryMapping
    public List<Paquete> paquetes() {
        return servicio.listarPaquetes();
    }

    @QueryMapping
    public List<Paquete> paquetesFiltrados(@Argument String envioCodigo, @Argument String descripcion) {
        return servicio.filtrarPaquetes(envioCodigo, descripcion);
    }

    @QueryMapping
    public Optional<Paquete> paquetePorCodigo(@Argument String codigo) {
        return servicio.buscarPorCodigo(codigo);
    }

    @QueryMapping
    public Optional<Paquete> paquetePorCriterios(@Argument String codigo, @Argument String envioCodigo,
                                                 @Argument String descripcion) {
        return servicio.buscarPorCriterios(codigo, envioCodigo, descripcion);
    }

    @MutationMapping
    public Optional<Paquete> addPaquete(@Argument("input") PaqueteInput input) {
        return servicio.addPaquete(input);
    }

    @MutationMapping
    public Optional<Paquete> updatePaquete(@Argument("input") PaqueteInput input) {
        return servicio.updatePaquete(input);
    }

    @MutationMapping
    public Optional<Paquete> deletePaquete(@Argument String codigo) {
        return servicio.deletePaquete(codigo);
    }
}
