package com.example.envio.servicios;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Publica el Singleton como bean para que Spring lo inyecte en los controladores.
 * Asi sigue existiendo una unica instancia compartida por todos los clientes.
 */
@Configuration
public class ConfiguracionServicios {

    @Bean
    public IServicioEnvioNacional servicioEnvioNacional() {
        return ServicioEnvioNacional.getInstance();
    }

    @Bean
    public IServicioPaquete servicioPaquete() {
        return ServicioPaquete.getInstance();
    }
}
