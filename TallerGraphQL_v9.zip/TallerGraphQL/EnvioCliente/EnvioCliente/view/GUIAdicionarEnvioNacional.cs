using System;
using System.Globalization;
using System.Windows.Forms;
using EnvioCliente.controller;

namespace EnvioCliente.view
{
    public partial class GUIAdicionarEnvioNacional : Form
    {
        public GUIAdicionarEnvioNacional()
        {
            InitializeComponent();
        }

        private async void btnAdicionar_Click(object sender, EventArgs e)
        {
            double precio;
            int codigoPostal;
            DateTime fechaSalida;

            if (!double.TryParse(txtPrecio.Text, out precio))
            {
                MessageBox.Show("El precio debe ser numerico.");
                return;
            }

            if (!int.TryParse(txtCodigoPostalNacional.Text, out codigoPostal))
            {
                MessageBox.Show("El codigo postal debe ser un numero entero.");
                return;
            }

            fechaSalida = txtFechaSalida.Value;

            try
            {
                await EnvioNacionalController.Instance.AdicionarAsync(
                    txtCodigo.Text, txtOrigen.Text, txtDestino.Text, precio, fechaSalida,
                    txtDepartamentoDestino.Text, codigoPostal);

                MessageBox.Show("Envio adicionado correctamente.");
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
