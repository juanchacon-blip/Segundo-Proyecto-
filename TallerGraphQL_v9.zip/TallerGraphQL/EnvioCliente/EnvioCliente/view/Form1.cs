using System;
using System.Windows.Forms;
using EnvioCliente.controller;
using EnvioCliente.observer;

namespace EnvioCliente.view
{
    public partial class Form1 : Form
    {
        private GUIListarEnvioNacional ventanaListar;
        private GUIListarPaquete ventanaListarPaquete;

        private ToolStripMenuItem graphQlMenuItem;
        private ToolStripMenuItem restMenuItem;

        public Form1()
        {
            InitializeComponent();
            construirMenuPaquete();
            construirMenuServicio();
            mostrarProtocolo();
        }

        // Menu "Paquete": casos de uso del detalle (cada opcion abre una ventana con un solo caso de uso).
        private void construirMenuPaquete()
        {
            var paqueteMenu = new ToolStripMenuItem("Paquete");
            paqueteMenu.DropDownItems.Add("Adicionar", null, (s, e) => new GUIAdicionarPaquete().ShowDialog());
            paqueteMenu.DropDownItems.Add("Consultar", null, (s, e) => new GUIConsultarPaquete().ShowDialog());
            paqueteMenu.DropDownItems.Add("Listar", null, (s, e) => abrirListarPaquete());
            paqueteMenu.DropDownItems.Add("Actualizar", null, (s, e) => new GUIActualizarPaquete().ShowDialog());
            paqueteMenu.DropDownItems.Add("Eliminar", null, (s, e) => new GUIEliminarPaquete().ShowDialog());

            menuStrip1.Items.Insert(menuStrip1.Items.IndexOf(envioNacionalToolStripMenuItem) + 1, paqueteMenu);
        }

        private void abrirListarPaquete()
        {
            // No modal: queda abierta mientras se usan otras ventanas y se refresca por Observer.
            if (ventanaListarPaquete == null || ventanaListarPaquete.IsDisposed)
            {
                ventanaListarPaquete = new GUIListarPaquete();
                ventanaListarPaquete.Show();
            }
            else
            {
                ventanaListarPaquete.Activate();
            }
        }

        // Menu "Servicio web": permite elegir si el cliente consume GraphQL o REST.
        private void construirMenuServicio()
        {
            graphQlMenuItem = new ToolStripMenuItem("GraphQL");
            restMenuItem = new ToolStripMenuItem("REST");

            graphQlMenuItem.Click += (s, e) => cambiarProtocolo(true);
            restMenuItem.Click += (s, e) => cambiarProtocolo(false);

            var servicioMenu = new ToolStripMenuItem("Servicio web");
            servicioMenu.DropDownItems.Add(graphQlMenuItem);
            servicioMenu.DropDownItems.Add(restMenuItem);

            menuStrip1.Items.Insert(menuStrip1.Items.IndexOf(ayudaToolStripMenuItem), servicioMenu);
        }

        private void cambiarProtocolo(bool graphQl)
        {
            if (graphQl)
            {
                EnvioNacionalController.Instance.UsarGraphQL();
            }
            else
            {
                EnvioNacionalController.Instance.UsarRest();
            }

            mostrarProtocolo();

            // Refresca la ventana Listar (si esta abierta) usando el nuevo protocolo.
            EnviosSubject.Instance.Notificar();
        }

        private void mostrarProtocolo()
        {
            bool graphQl = EnvioNacionalController.Instance.Protocolo == "GraphQL";
            graphQlMenuItem.Checked = graphQl;
            restMenuItem.Checked = !graphQl;
            Text = "Gestión de Envíos Nacionales - " + EnvioNacionalController.Instance.Protocolo;
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void adicionarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new GUIAdicionarEnvioNacional().ShowDialog();
        }

        private void consultarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new GUIConsultarEnvioNacional().ShowDialog();
        }

        private void listarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // No modal: queda abierta mientras se usan otras ventanas y se refresca por Observer.
            if (ventanaListar == null || ventanaListar.IsDisposed)
            {
                ventanaListar = new GUIListarEnvioNacional();
                ventanaListar.Show();
            }
            else
            {
                ventanaListar.Activate();
            }
        }

        private void actualizarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new GUIActualizarEnvioNacional().ShowDialog();
        }

        private void eliminarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new GUIEliminarEnvioNacional().ShowDialog();
        }

        private void acercaDeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(
                "Gestión de Envíos Nacionales\nVersión 1.0\n\nIntegrantes:\n" +
                "Juan Esteban Molano Polanco codigo 2220232008\n" +
                "Juan Pablo Chacon codigo 2220232030\n" +
                "Johan Daniel Esterling codigo 2220241033",
                "Acerca de...");
        }
    }
}
